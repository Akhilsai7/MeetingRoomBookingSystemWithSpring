-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: mrbs
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meeting_request`
--

DROP TABLE IF EXISTS `meeting_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meeting_request` (
  `id` int(11) NOT NULL,
  `enddate` varchar(255) DEFAULT NULL,
  `endtime` varchar(255) DEFAULT NULL,
  `mrname` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `startdate` varchar(255) DEFAULT NULL,
  `starttime` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `timestamp` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_request`
--

LOCK TABLES `meeting_request` WRITE;
/*!40000 ALTER TABLE `meeting_request` DISABLE KEYS */;
INSERT INTO `meeting_request` VALUES (1,'2019-08-17','02:00','comakeit','speaker','2019-08-16','01:00','ACCEPTED','09:17:29','2019-08-29','rahul'),(2,'2019-08-29','02:00','Ar','speaker','2019-08-29','01:00','REJECTED','09:17:29','2019-08-29','rahul'),(3,'2019-08-07','02:00','comakeit','speaker','2019-08-07','01:01','CANCELLED','11:37:55','2019-08-29','rahul'),(4,'2019-08-29','05:00','comakeit','speaker','2019-08-29','04:00','CENCELLED','16:19:01','2019-08-29','keerthi'),(5,'2019-08-30','02:00','comakeit','speaker','2019-08-29','01:00','REJECTED','16:34:14','2019-08-29','rahul'),(6,'2019-08-30','02:00','Abdul kalam','stylus','2019-08-30','01:00','ACCEPTED','09:40:32','2019-08-30','keerthi'),(7,'2019-08-30','04:00','MeetingRoom5','Television','2019-08-30','03:01','CANCELLED','09:40:32','2019-08-30','keerthi'),(8,'2019-08-30','02:00','Ar','speaker','2019-08-30','01:00','NEW','11:58:05','2019-08-30','rahul');
/*!40000 ALTER TABLE `meeting_request` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-04 12:01:53
